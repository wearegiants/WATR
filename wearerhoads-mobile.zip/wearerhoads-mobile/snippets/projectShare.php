<div class="meta">
	<a href="#" class="add">Add to Lightbox</a>
	<a href="#" class="download">Download</a>
	<a href="#" class="share">Share</a>
	<div class="titles">
		<span class="add">Add to Lightbox</span>
		<span class="download">Download</span>
		<span class="share">Share</span>
	</div>
</div>
