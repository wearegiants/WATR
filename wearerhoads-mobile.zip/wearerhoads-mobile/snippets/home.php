<div id="front" class="wrapper">
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.01b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.02b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.03b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.04b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.05b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.06b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.07b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.08b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.09b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.10b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.11b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.12b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.13b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.14b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.15b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.16b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.17b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.18b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.19b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.20b.jpg"></span></a></div>
	<div class="item"><a href="project.html"><h3>Project Title</h3><span class="thumb"><img class="small" src="images/front/rhoads.21b.jpg"></span></a></div>
</div>