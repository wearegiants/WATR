<li class="active"><a href="/projects/WATR/pageGallery.php">New Work</a></li>
<li><a href="/projects/WATR/pageGallery.php">Lifestyle</a></li>
<li><a href="/projects/WATR/pageGallery.php">People</a></li>
<li><a href="/projects/WATR/pageGallery.php">Kids</a></li>
<li class="sub" id="btnProjects">
	<span id="menuProjects">Projects</span>
	<ul class="menuSub">
		<li><a href="/projects/WATR/pageProject.php">Kinfolk Spring</a></li>
		<li><a href="/projects/WATR/pageProject.php">Motorcycle Diaries</a></li>
	</ul>
</li>
<li><a href="/projects/WATR/pageGallery.php">Advertising</a></li>
<li><a href="video.html">Video</a></li>