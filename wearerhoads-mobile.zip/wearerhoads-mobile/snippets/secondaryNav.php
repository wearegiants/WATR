<li><a href="/projects/WATR/pageInfo.php">Info</a></li>
<li><a href="/projects/WATR/pageClients.php">Clients</a></li>
<li><a href="http://blog.wearetherhoads.com/">Blog</a></li>
<li id="btnSearch">Search</li>
<li><a href="#">Lightbox</a></li>
<li id="searchBox">
	<div><form><input type="text" /></form></div>
</li>