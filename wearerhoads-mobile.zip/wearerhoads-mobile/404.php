<?php get_header(); ?>
<div id="content">
<div id="post-0" class="post error404 not-found">
<h1 class="entry-title"><span><?php _e('Oh no, 404 :('); ?></span></h1>
<div class="entry-content">
<p><?php _e('Bummer guys, nothing here.'); ?></p>
</div>
</div>
</div>
<?php get_footer(); ?>